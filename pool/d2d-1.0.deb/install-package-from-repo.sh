deb https://github.com/waltervfaustine/d2d-dhis-docker-implementation/tree/main/dists/stable stable main

deb [arch=amd64] https://github.com/waltervfaustine/d2d-dhis-docker-implementation/tree/main/dists/stable stable main

sudo apt-get update

sudo apt-get install d2d


