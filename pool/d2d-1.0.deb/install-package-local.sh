# Example command to install the built .deb package
sudo dpkg -i pool/d2d-1.0.deb